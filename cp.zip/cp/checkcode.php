<?php  

include 'dbconnect.php';
 session_start();
  $username = $_SESSION['username'];
  $expdate = $_SESSION['expdate'];
      
      $cpcode = $_POST['cpcode'];
      $phone = $_POST['phone'];

      
      $sql = "SELECT * FROM `list` WHERE `cp_code` = '$cpcode' AND `phone` = '$phone' AND `status`='Yes'";
     // echo $sql;
      $result = $conn->query($sql);
      $list = "SELECT * FROM list WHERE `cp_code` = '$cpcode'";
       $select = $conn->query($list);
       $res = mysqli_fetch_object($select);
       // echo $res->listid;
       // echo $res->cp_code;
     
     // $ex = $result;
     // echo $result->listid;
   //  echo "visa" ;
     //printr($result->num_rows);

  if ("SELECT * FROM `list` WHERE `expdate` = '$expdate'") 
  {
    // if("status" = )
   // echo "Yes";
    $update = "UPDATE `list` SET `status` = 'No',`username`= '$username',`phone` = '$phone' WHERE `listid` = '$res->listid'";
   $conn->query($update);
   ?>

     <div class="page-center">
         <div class="page-center-in">
             <div class="container-fluid">
                 <form class="sign-box" action="coupon.php" method="POST">
                     <div class="no-photo" style="text-align: center;"><img src="image/logo.png"></div>
                     <header class="sign-title">Validate Updates</header>
                     <div class="alert alert-aquamarine alert-border-left alert-close alert-dismissible fade in" role="alert">
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true">×</span>
                             </button>
                             <strong>Hurrya!</strong> Your Coupon Code is validated. YOur Coupon is active now
                         </div>

                    

                    
                     <button type="submit" class="btn btn-rounded btn-success sign-up">Next!</button>
                    
                    
                 </form>
             </div>
         </div>
     </div>
     <?php
   }
else{
?>    
<div class="page-center">
         <div class="page-center-in">
             <div class="container-fluid">
                 <form class="sign-box" action="coupon.php" method="POST">
                     <div class="no-photo" style="text-align: center;"><img src="image/logo.png"></div>
                     <header class="sign-title">Validate Updates</header>
                    

                     <div class="alert alert-danger alert-border-left alert-close alert-dismissible fade in" role="alert">
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                 <span aria-hidden="true">×</span>
                             </button>
                             <strong>Sorry!</strong> Your Coupon Code is invalid. Please contact  Bharat Jewels.
                         </div>
                   

                    
                    
                     <button type="submit" class="btn btn-rounded btn-success sign-up">Go Back and Check</button>
                    
                    
                 </form>
             </div>
         </div>
     </div>
 <?php
}
  //echo "In valid ";
   //header("location: coupon.php");
  //die;

//header("location: index.php");
?>
<!DOCTYPE html>
<html>

<!-- sign-up.html  16:14 GMT -->
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Bharat Jewels</title>

	<link href="img/favicon.144x144.html" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.html" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.html" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.html" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.html" rel="icon" type="image/png">
	<link href="img/favicon-2.html" rel="shortcut icon">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
    <link rel="stylesheet" href="css/lib/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>


<script src="js/app.js"></script>
</body>

<!-- sign-up.html  16:14 GMT -->
</html>














        
