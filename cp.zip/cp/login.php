<?php  
include 'dbconnect.php';

      $myusername = $_POST['username'];
      $mypassword = $_POST['password']; 

      $sql = "SELECT * FROM `users` WHERE `username` = '$myusername' AND `password`= '$mypassword'";
     echo $sql;
      //die;
      $result = $conn->query($sql);
      $res =mysqli_fetch_object($result);
      if($result->num_rows > 0)
  {
    session_start();
    $_SESSION['username']=$res->username;
    echo $_SESSION['username'];
    $_SESSION['expdate'] = $res->expdate;
    $_SESSION['status'] = $res->status;
    $_SEESION['password']=$res->password;
    header('Location:coupon.php');
  }
  else
  { 
    header("location: index.php");
  }
//    if () {
//      // echo  $sql;
        
// 	    $_SESSION['login_user'] = $myusername;
// 	     // echo $_SESSION['login_user'];
// 	     header("location: coupon.php");
// 	  //   die;


//       } 

// else
//  {
// //  $_SESSION['login_user'] = $myusername;
//   //     echo $_SESSION['login_user'];
//     //  die;
//        header("location: index.php");
// }
// $conn->close();



?>
        
